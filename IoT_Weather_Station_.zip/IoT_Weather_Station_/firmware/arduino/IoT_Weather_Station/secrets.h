#ifndef SECRETS_H
#define SECRETS_H

/*
 * Replace every YOUR_* placeholder before flashing real hardware.
 * Do not commit real passwords or API keys.
 *
 * Wokwi internet access (browser simulation only):
 *   WIFI_SSID       "Wokwi-GUEST"
 *   WIFI_PASSWORD   ""
 */

#ifndef WIFI_SSID
#define WIFI_SSID "YOUR_WIFI_SSID"
#endif

#ifndef WIFI_PASSWORD
#define WIFI_PASSWORD "YOUR_WIFI_PASSWORD"
#endif

#ifndef THINGSPEAK_WRITE_API_KEY
#define THINGSPEAK_WRITE_API_KEY "YOUR_THINGSPEAK_WRITE_API_KEY"
#endif

#ifndef THINGSPEAK_CHANNEL_ID
#define THINGSPEAK_CHANNEL_ID 0
#endif

/* Optional IFTTT Webhooks email path. Leave as YOUR_* to disable. */
#ifndef IFTTT_EVENT_NAME
#define IFTTT_EVENT_NAME "YOUR_IFTTT_EVENT_NAME"
#endif

#ifndef IFTTT_WEBHOOK_KEY
#define IFTTT_WEBHOOK_KEY "YOUR_IFTTT_WEBHOOK_KEY"
#endif

#endif
