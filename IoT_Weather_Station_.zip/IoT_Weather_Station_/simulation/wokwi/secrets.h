#ifndef SECRETS_H
#define SECRETS_H

/*
 * Wokwi uses the public SSID Wokwi-GUEST (overridden in config.h).
 * Put your ThingSpeak write API key here if you want the simulation to
 * publish live data. Leave placeholders to test sensor/Wi-Fi paths only.
 */

#define WIFI_SSID "YOUR_WIFI_SSID"
#define WIFI_PASSWORD "YOUR_WIFI_PASSWORD"
#define THINGSPEAK_WRITE_API_KEY "YOUR_THINGSPEAK_WRITE_API_KEY"
#define THINGSPEAK_CHANNEL_ID 0
#define IFTTT_EVENT_NAME "YOUR_IFTTT_EVENT_NAME"
#define IFTTT_WEBHOOK_KEY "YOUR_IFTTT_WEBHOOK_KEY"

#endif
