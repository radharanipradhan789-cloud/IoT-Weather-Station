#include <WiFi.h>
#include <HTTPClient.h>
#include <DHT.h>

#define DHTPIN 4
#define DHTTYPE DHT22

#define WIFI_SSID "Wokwi-GUEST"
#define WIFI_PASSWORD ""

#define TEMP_HIGH 35.0
#define TEMP_LOW 10.0
#define HUMIDITY_HIGH 80.0
#define HUMIDITY_LOW 20.0
const char* THINGSPEAK_API_KEY = "PYMFD6IHTZL9Q5E5";
const char* THINGSPEAK_SERVER = "http://api.thingspeak.com";
DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println("IoT Weather Station - Wokwi simulation");

  dht.begin();

  Serial.println("[WIFI] Connecting to Wokwi-GUEST ...");

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD, 6);

  unsigned long startTime = millis();

  while (WiFi.status() != WL_CONNECTED &&
         millis() - startTime < 20000) {
    delay(500);
    Serial.print(".");
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println();
    Serial.print("[WIFI] Connected. IP=");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println();
    Serial.println("[WIFI] Connection failed.");
  }
}

void loop() {
  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();

  if (isnan(temperature) || isnan(humidity)) {
    Serial.println("[SENSOR] Failed to read from DHT22!");
  } else {
    Serial.printf(
      "[SENSOR] Temperature=%.2f C  Humidity=%.2f %%RH\n",
      temperature, humidity
    );

    if (temperature > TEMP_HIGH) {
      Serial.println("[ALERT] High temperature detected!");
    } else if (temperature < TEMP_LOW) {
      Serial.println("[ALERT] Low temperature detected!");
    }

    if (humidity > HUMIDITY_HIGH) {
      Serial.println("[ALERT] High humidity detected!");
    } else if (humidity < HUMIDITY_LOW) {
      Serial.println("[ALERT] Low humidity detected!");
    }

    uploadToThingSpeak(temperature, humidity);
  }

  delay(20000);
}
void uploadToThingSpeak(float temperature, float humidity) {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("[CLOUD] Wi-Fi disconnected. Upload skipped.");
    return;
  }

  HTTPClient http;

  String url = String(THINGSPEAK_SERVER);
  url += "/update?api_key=";
  url += THINGSPEAK_API_KEY;
  url += "&field1=";
  url += String(temperature, 2);
  url += "&field2=";
  url += String(humidity, 2);

  http.begin(url);
  int httpCode = http.GET();

  if (httpCode > 0) {
    String response = http.getString();

    if (response.toInt() > 0) {
      Serial.println("[CLOUD] Upload successful.");
    } else {
      Serial.println("[CLOUD] Upload not accepted. Check API key or update rate.");
    }
  } else {
    Serial.printf("[CLOUD] HTTP error: %s\n",
                  http.errorToString(httpCode).c_str());
  }

  http.end();
}

