#ifndef CONFIG_H
#define CONFIG_H

#include <string.h>
#include "secrets.h"

#ifndef WOKWI_SIMULATION
#define WOKWI_SIMULATION 1
#endif

#if WOKWI_SIMULATION
#undef WIFI_SSID
#undef WIFI_PASSWORD
#define WIFI_SSID "Wokwi-GUEST"
#define WIFI_PASSWORD ""
#define WIFI_CHANNEL 6
#else
#define WIFI_CHANNEL 0
#endif

#define DHT_PIN 4
#define DHT_TYPE DHT22
#define STATUS_LED_PIN 2

#define SENSOR_RETRY_COUNT 3
#define SENSOR_RETRY_DELAY_MS 2000
#define MIN_VALID_TEMP_C -40.0f
#define MAX_VALID_TEMP_C 80.0f
#define MIN_VALID_HUM_PCT 0.0f
#define MAX_VALID_HUM_PCT 100.0f

#define UPLOAD_INTERVAL_MS 20000UL
#define WIFI_CONNECT_TIMEOUT_MS 20000UL
#define WIFI_RETRY_DELAY_MS 5000UL
#define HTTP_TIMEOUT_MS 12000
#define UPLOAD_RETRY_COUNT 2

#define USE_HTTPS 0
#define THINGSPEAK_HOST "api.thingspeak.com"
#define THINGSPEAK_HTTP_PORT 80
#define THINGSPEAK_HTTPS_PORT 443

#define ENABLE_IFTTT_ALERTS 1
#define TEMP_HIGH_C 35.0f
#define TEMP_LOW_C 10.0f
#define HUM_HIGH_PCT 80.0f
#define HUM_LOW_PCT 20.0f
#define ALERT_COOLDOWN_MS 300000UL

#define SERIAL_BAUD 115200

inline bool isPlaceholder(const char *value) {
  return value == nullptr || value[0] == '\0' || strstr(value, "YOUR_") != nullptr;
}

#endif
