# IoT-Based Weather Station Using ESP32 and Cloud Dashboard

## Abstract

This project presents an IoT-based weather monitoring system using an ESP32 microcontroller and a DHT22 temperature and humidity sensor. The system collects environmental readings, connects to Wi-Fi, and uploads temperature and humidity data to the ThingSpeak cloud platform for visualization. It checks sensor readings against predefined thresholds and displays alerts in the Serial Monitor when temperature or humidity exceeds the configured limits. The project was developed and tested using the Wokwi simulation environment. Testing confirmed successful Wi-Fi connectivity, sensor readings, threshold alerts, cloud uploads, and graphical visualization through the ThingSpeak dashboard. This project demonstrates the use of Internet of Things (IoT) technology for remote environmental monitoring. Physical hardware testing and email notification delivery have not yet been verified.

## Testing

The project was tested using the Wokwi ESP32 simulation environment, a DHT22 sensor model, and a configured ThingSpeak channel.

The following tests were performed:

| Test                             | Procedure                                               | Observed Result                                           | Status |
| -------------------------------- | ------------------------------------------------------- | --------------------------------------------------------- | ------ |
| Wi-Fi connectivity               | Start the ESP32 simulation and check the Serial Monitor | Connected to Wokwi-GUEST and obtained an IP address       | Pass   |
| Temperature and humidity reading | Read the DHT22 sensor values                            | Temperature and humidity values were displayed            | Pass   |
| High-temperature alert           | Set the simulated temperature above 35°C                | High-temperature alert appeared                           | Pass   |
| High-humidity alert              | Set the simulated humidity above 80%                    | High-humidity alert appeared                              | Pass   |
| ThingSpeak upload                | Send sensor readings to the configured channel          | Serial Monitor reported a successful upload               | Pass   |
| Cloud visualization              | Open the ThingSpeak Private View dashboard              | Temperature and humidity graphs displayed recorded values | Pass   |

These results are based on the tests performed during the project implementation. The simulation was used to validate sensor reading, alert generation, network connectivity, and cloud data visualization.

Email delivery and physical hardware operation have not been verified and are not reported as completed tests.

## Results

The project demonstrates an IoT-based weather monitoring workflow using an ESP32, a DHT22 sensor, Wi-Fi connectivity, and the ThingSpeak cloud platform.

The verified outcomes are:

* Temperature and humidity readings were obtained from the simulated DHT22 sensor.
* The ESP32 connected successfully to the Wokwi guest Wi-Fi network.
* High-temperature and high-humidity conditions generated the expected serial alerts.
* Sensor readings were successfully uploaded to the configured ThingSpeak channel.
* The ThingSpeak dashboard displayed temperature and humidity graphs with recorded data points.

The results confirm that the core monitoring and cloud-visualization functions operate in simulation.

Email notifications, physical hardware testing, and any additional firmware features require separate verification before they can be claimed as completed.
## Conclusion

The IoT-Based Weather Station demonstrates environmental monitoring using an ESP32 microcontroller, a DHT22 temperature and humidity sensor, Wi-Fi connectivity, and the ThingSpeak cloud platform. The system was successfully tested in the Wokwi simulation environment. It collected temperature and humidity readings, detected threshold violations, displayed alerts in the Serial Monitor, and uploaded sensor data to ThingSpeak for graphical visualization.

The project demonstrates how IoT technology can be used to collect, transmit, and visualize environmental data remotely. Although the core monitoring and cloud-upload functions have been verified in simulation, physical hardware testing and email notification delivery remain unverified. These can be considered future improvements to extend the system beyond its current implementation.
