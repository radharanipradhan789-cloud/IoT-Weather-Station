# IoT-Based Weather Station Using ESP32 and Cloud Dashboard

## 1. Project Overview

The IoT-Based Weather Station is a weather monitoring system developed using an ESP32 microcontroller and a DHT22 temperature and humidity sensor. The system collects environmental readings, connects to Wi-Fi, detects threshold violations, and uploads sensor data to the ThingSpeak cloud platform for visualization.

The project is simulated using Wokwi and uses ThingSpeak to display temperature and humidity readings through graphical dashboards.

## 2. Project Objectives

* Measure temperature and relative humidity using a DHT22 sensor.
* Connect the ESP32 to Wi-Fi.
* Display sensor readings through the Serial Monitor.
* Detect high and low temperature and humidity conditions.
* Upload sensor data to ThingSpeak.
* Visualize historical sensor readings using cloud-based graphs.

## 3. Technologies Used

| Component   | Purpose                                           |
| ----------- | ------------------------------------------------- |
| ESP32       | Reads sensor data and manages Wi-Fi communication |
| DHT22       | Measures temperature and humidity                 |
| Wokwi       | Simulates the ESP32 and sensor circuit            |
| Arduino C++ | Implements the firmware                           |
| ThingSpeak  | Stores and visualizes sensor readings             |
| Wi-Fi       | Provides internet connectivity for cloud uploads  |

## 4. Hardware and Sensor Connections

The project uses a simulated ESP32 development board and a DHT22 sensor.

| DHT22 Pin | ESP32 Connection |
| --------- | ---------------- |
| VCC       | 3V3              |
| GND       | GND              |
| DATA      | GPIO 4           |

These connections describe the intended circuit. The project is currently tested in simulation rather than on physical hardware.

## 5. Working Principle

1. The ESP32 starts and initializes the DHT22 sensor.
2. It connects to the Wokwi guest Wi-Fi network.
3. The DHT22 provides temperature and humidity readings.
4. The ESP32 displays the readings in the Serial Monitor.
5. The firmware compares the readings against configured thresholds.
6. When a threshold is crossed, the system prints an alert.
7. The ESP32 sends the temperature and humidity values to ThingSpeak.
8. ThingSpeak records the uploaded values and displays them as graphs.

## 6. Alert Thresholds

The current firmware uses the following thresholds:

| Parameter   | Condition  | Alert                     |
| ----------- | ---------- | ------------------------- |
| Temperature | Above 35°C | High temperature detected |
| Temperature | Below 10°C | Low temperature detected  |
| Humidity    | Above 80%  | High humidity detected    |
| Humidity    | Below 20%  | Low humidity detected     |

These thresholds can be adjusted in the firmware.

## 7. ThingSpeak Configuration

The ThingSpeak channel is configured with two fields:

* **Field 1:** Temperature (°C)
* **Field 2:** Humidity (%)

The ESP32 uploads the sensor readings using the channel's Write API Key. ThingSpeak displays the recorded data in the Private View dashboard.

For the free ThingSpeak service, allow at least 15 seconds between channel updates. The simulation can use a 20-second interval to avoid update-rate rejections.

**Security:** Never publish the real ThingSpeak Write API Key, Wi-Fi passwords, or other credentials in this repository.

## 8. Testing and Results

The following behaviours have been observed during simulation testing:

| Test                    | Expected Behaviour                                      | Observed Result |
| ----------------------- | ------------------------------------------------------- | --------------- |
| Wi-Fi connection        | ESP32 connects to Wokwi guest Wi-Fi                     | Successful      |
| Sensor reading          | Temperature and humidity appear in the Serial Monitor   | Successful      |
| High humidity           | Alert appears when humidity exceeds 80%                 | Successful      |
| High temperature        | Alert appears when temperature exceeds 35°C             | Successful      |
| ThingSpeak upload       | Sensor readings are accepted by the cloud channel       | Successful      |
| Dashboard visualization | Temperature and humidity graphs display recorded values | Successful      |

These results are based on the simulation tests performed for this project. Additional tests should be recorded only after they have actually been performed.

## 9. Project Structure

```text
IoT_Weather_Station/
├── cloud/
│   └── thingspeak/
├── docs/
├── firmware/
├── simulation/
│   └── wokwi/
├── tools/
├── screenshots/
├── README.md
├── TECHNICAL_REPORT.md
├── TEST_CASES.md
├── DEPENDENCIES.md
└── platformio.ini
```

The listed files and folders should be checked against the actual project directory before submission.

## 10. Running the Simulation

1. Open the Wokwi ESP32 project.
2. Verify that the DHT22 data pin is connected to GPIO 4.
3. Check that the Wi-Fi configuration uses `Wokwi-GUEST` with an empty password.
4. Confirm that the ThingSpeak Write API Key is configured privately.
5. Start the simulation.
6. Open the Serial Monitor and check the connection and sensor readings.
7. Adjust the DHT22 temperature and humidity values to test threshold alerts.
8. Open the ThingSpeak Private View dashboard to verify uploaded readings.

Keep the cloud upload interval at 20 seconds or longer when using the free ThingSpeak service.

## 11. Limitations

* The current implementation has been tested in Wokwi simulation.
* Physical ESP32 hardware testing has not been confirmed.
* Email notifications and IFTTT integration are not claimed as implemented features.
* The system depends on Wi-Fi connectivity for cloud uploads.
* Sensor accuracy depends on the sensor model and its operating conditions.

## 12. Conclusion

The project demonstrates an IoT-based environmental monitoring workflow using an ESP32, DHT22 sensor, Wi-Fi connectivity, and the ThingSpeak cloud platform. The simulation successfully reads temperature and humidity, generates threshold alerts, uploads readings, and displays the recorded data through dashboard graphs.

The project provides a foundation for future development, including physical hardware deployment, improved notification mechanisms, and additional environmental sensors.
