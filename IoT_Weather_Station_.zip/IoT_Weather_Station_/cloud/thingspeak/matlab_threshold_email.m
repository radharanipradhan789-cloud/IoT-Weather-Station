% ThingSpeak MATLAB Analysis: email when temperature or humidity
% crosses the configured limits.
%
% Paste this into Apps > MATLAB Analysis on your channel.
% Replace every YOUR_* placeholder. ThingSpeak Alerts emails the
% address on the MathWorks account that owns the channel.

readChannelID = 0;  % YOUR_THINGSPEAK_CHANNEL_ID (numeric)
readAPIKey = 'YOUR_THINGSPEAK_READ_API_KEY';
alertApiKey = 'YOUR_THINGSPEAK_ALERTS_API_KEY';

tempHighC = 35;
tempLowC = 10;
humHighPct = 80;
humLowPct = 20;

latest = thingSpeakRead(readChannelID, ...
    'NumPoints', 1, ...
    'Fields', [1, 2], ...
    'ReadKey', readAPIKey);

if isempty(latest) || any(isnan(latest))
    fprintf('No valid ThingSpeak sample; skipping alert.\n');
    return
end

temperatureC = latest(1);
humidityPct = latest(2);

hot = temperatureC > tempHighC;
cold = temperatureC < tempLowC;
humid = humidityPct > humHighPct;
dry = humidityPct < humLowPct;

if ~(hot || cold || humid || dry)
    fprintf('Within limits: T=%.2f C, H=%.2f %%RH\n', temperatureC, humidityPct);
    return
end

reasons = {};
if hot, reasons{end+1} = sprintf('temperature %.2f C > %.1f C', temperatureC, tempHighC); end
if cold, reasons{end+1} = sprintf('temperature %.2f C < %.1f C', temperatureC, tempLowC); end
if humid, reasons{end+1} = sprintf('humidity %.2f %% > %.1f %%', humidityPct, humHighPct); end
if dry, reasons{end+1} = sprintf('humidity %.2f %% < %.1f %%', humidityPct, humLowPct); end

alertSubject = 'IoT Weather Station threshold alert';
alertBody = sprintf([ ...
    'An IoT weather station channel exceeded a configured limit.\n\n', ...
    'Temperature: %.2f C\n', ...
    'Humidity: %.2f %%RH\n', ...
    'Reason: %s\n'], ...
    temperatureC, humidityPct, strjoin(reasons, '; '));

if ~isempty(strfind(alertApiKey, 'YOUR_'))
    fprintf('Alerts API key is a placeholder. Email not sent.\n%s\n', alertBody);
    return
end

alertUrl = 'https://api.thingspeak.com/alerts/send';
options = weboptions('HeaderFields', {'ThingSpeak-Alerts-API-Key', alertApiKey});
webwrite(alertUrl, 'subject', alertSubject, 'body', alertBody, options);
fprintf('Alert request submitted.\n');
