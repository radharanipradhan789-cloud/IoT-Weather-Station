# Run in Wokwi (Option 1)

You only need two files: `sketch.ino` and `diagram.json`.

1. Open this link: https://wokwi.com/projects/new/esp32
2. In the code editor, delete the default sketch and paste **all** of `sketch.ino`.
3. Click the `diagram.json` tab (top of the editor) and paste **all** of `diagram.json`.
4. Click the library icon (book / +) and add:
   - `DHT sensor library`
   - `Adafruit Unified Sensor`
5. Press the green **Play** button.
6. Open **Serial Monitor** at the bottom.

Expected first lines:

```text
IoT Weather Station - Wokwi simulation
[CONFIG] ThingSpeak write API key is a placeholder. Uploads will be skipped.
[WIFI] Connecting to Wokwi-GUEST ...
[WIFI] Connected. IP=...
[SENSOR] Temperature=26.50 C  Humidity=55.00 %RH
[CLOUD] Placeholder API key; upload skipped.
```

Click the DHT22 on the canvas and drag temperature above 35 °C to see `[ALERT]`.

ThingSpeak graphs need a real write API key in `sketch.ino` (`THINGSPEAK_WRITE_API_KEY`). Leave the placeholder if you only want the simulator.
