# Dependencies

## Arduino IDE (2.x recommended)

1. Install [Arduino IDE](https://www.arduino.cc/en/software).
2. Boards Manager: `esp32` by Espressif Systems (Arduino-ESP32 2.x or 3.x).
3. Select board: **ESP32 Dev Module** (or your exact DevKit).
4. Library Manager:

| Library | Author | Version used in this repo |
| --- | --- | --- |
| DHT sensor library | Adafruit | 1.4.6 or newer |
| Adafruit Unified Sensor | Adafruit | 1.1.15 or newer |

Built-in (Arduino-ESP32): `WiFi`, `HTTPClient`.

## PlatformIO

Root file: `platformio.ini`.

```text
platform = espressif32
framework = arduino
board = esp32dev
lib_deps =
  adafruit/DHT sensor library@^1.4.6
  adafruit/Adafruit Unified Sensor@^1.1.15
```

## Wokwi

Libraries listed in `simulation/wokwi/libraries.txt`:

```text
DHT sensor library
Adafruit Unified Sensor
```

## Cloud (no local packages)

- ThingSpeak / MathWorks account
- Optional IFTTT Webhooks + Email applet

## Local checks (optional)

Python 3.8+ standard library only: `python tools/validate_project.py`
