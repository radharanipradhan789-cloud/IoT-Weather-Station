# Hardware Wiring (ESP32 + DHT22)

The DHT22 sensor measures temperature and relative humidity. It connects to the ESP32 through a data pin configured as GPIO 4.

## Wiring Table

| DHT22 Pin       | ESP32 DevKit Pin | Wire Color     |
| --------------- | ---------------- | -------------- |
| VCC             | 3V3              | Red            |
| DATA            | GPIO 4           | Green          |
| GND             | GND              | Black          |
| NC (if present) | Not connected    | Not applicable |

Use the 3.3 V supply for the sensor. If the DHT22 module does not include an internal pull-up resistor, a 4.7 kΩ to 10 kΩ resistor may be connected between DATA and 3.3 V.

## Connection Diagram

```text
ESP32 DevKit             DHT22 Sensor

3V3  ------------------- VCC
GPIO 4 ----------------- DATA
GND  ------------------- GND
                         NC: Not connected
```

**Power supply:** Power the ESP32 through USB when running the simulation or using a physical development board.

**Implementation note:** The wiring described above matches the intended ESP32 and DHT22 connection. Physical hardware operation has not yet been verified; the project was tested using the Wokwi simulation.
