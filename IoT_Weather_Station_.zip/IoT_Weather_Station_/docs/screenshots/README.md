# Screenshot Evidence

This folder contains screenshots captured during testing of the IoT Weather Station project.

## Available Screenshots

| Filename                                    | Description                                                  | Status   |
| ------------------------------------------- | ------------------------------------------------------------ | -------- |
| `01-wokwi-wiring.png`                       | ESP32 and DHT22 circuit in Wokwi                             | Captured |
| `02-wokwi-serial-sensor.png`                | Sensor readings, threshold alerts, and cloud upload output   | Captured |
| `03-thingspeak-Temperature-Humidity-...png` | ThingSpeak dashboard showing temperature and humidity graphs | Captured |

## Verification Notes

The Wokwi simulation, sensor readings, threshold alerts, ThingSpeak uploads, and dashboard graphs were tested.

Email alerts, physical hardware operation, and ThingSpeak React triggers have not been verified.

Only genuine screenshots from actual project runs should be submitted. Do not create fabricated evidence or mark untested features as successful.
