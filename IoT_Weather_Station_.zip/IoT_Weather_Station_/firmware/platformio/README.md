# PlatformIO build

The PlatformIO project lives at the repository root (`platformio.ini`).

```bash
pio run -e esp32dev
pio run -e esp32dev --target upload
pio device monitor
```

Wokwi-oriented firmware flags:

```bash
pio run -e wokwi
```
