# ThingSpeak channel and email-alert setup

Do not paste real API keys into this repository. Keep them in `secrets.h` on your machine and in the ThingSpeak MATLAB UI only.

## 1. Create a MathWorks / ThingSpeak account

1. Open [https://thingspeak.com](https://thingspeak.com) and sign in with a MathWorks account.
2. Confirm you can receive email at the address on that account (ThingSpeak Alerts uses it).

## 2. Create the weather channel (two fields)

1. Click **Channels → My Channels → New Channel**.
2. Set **Name** to `IoT Weather Station` (or your own title).
3. Enable **Field 1**. Name it `Temperature`.
4. Enable **Field 2**. Name it `Humidity`.
5. Leave Fields 3–8 disabled.
6. Save the channel.

### Field mapping used by the firmware

| ThingSpeak field | Sensor quantity | Unit | Firmware query parameter |
| --- | --- | --- | --- |
| Field 1 | Temperature | °C | `field1` |
| Field 2 | Humidity | %RH | `field2` |

## 3. Copy keys into firmware placeholders

On the channel **API Keys** tab:

| Secret | Where it goes |
| --- | --- |
| Write API Key | `THINGSPEAK_WRITE_API_KEY` in `firmware/arduino/IoT_Weather_Station/secrets.h` |
| Read API Key | MATLAB Analysis `readAPIKey` |
| Channel ID | MATLAB Analysis `readChannelID` and optional `THINGSPEAK_CHANNEL_ID` |

Free community channels accept a new point about every **15 seconds**. The firmware uploads every **20 seconds**.

## 4. Live graphs (data visualization)

On the channel **Private View** (or **Public View** if you made the channel public):

1. Field 1 chart is temperature versus time.
2. Field 2 chart is humidity versus time.
3. Optional: **Add Visualizations → MATLAB Visualization** if you want a combined plot.

Suggested chart titles:

- `Temperature (°C)`
- `Humidity (%RH)`

## 5. Email alerts via ThingSpeak Alerts + MATLAB Analysis

This section describes the configuration steps for ThingSpeak email alerts using MATLAB Analysis and React. Email alerts have not yet been verified in the current project, so this section is provided as a setup guide rather than evidence of successful email delivery.


1. Open **Apps → MATLAB Analysis → New**.
2. Name it `Weather threshold email`.
3. Paste `cloud/thingspeak/matlab_threshold_email.m`.
4. Replace:
   - `readChannelID`
   - `YOUR_THINGSPEAK_READ_API_KEY`
   - `YOUR_THINGSPEAK_ALERTS_API_KEY`
   - threshold constants if you changed `config.h`
5. Click **Save and Run** once with a known in-range sample to confirm the script executes.
6. Find the **ThingSpeak Alerts API Key** under **Account → My Profile** (Alerts section).
7. Open **Apps → React → New React**:
   - **Condition Type:** Numeric
   - **Channel:** your weather channel
   - **Field:** Field 1 (Temperature)
   - **Condition:** greater than `35` (or your `TEMP_HIGH_C`)
   - **Action:** MATLAB Analysis → `Weather threshold email`
   - **Options:** Run action only when the condition is met (avoid spam)
8. Add a second React for humidity: Field 2 greater than `80`.
9. Optional extra Reacts: Field 1 less than `10`, Field 2 less than `20`.

When a React fires, MATLAB calls `https://api.thingspeak.com/alerts/send`. ThingSpeak emails the MathWorks account address. Daily alert quotas apply on the free tier.

## 6. Optional firmware email path (IFTTT)

Use this if you want the ESP32 to trigger email itself as well as the cloud React.

1. Create an IFTTT applet: **If Webhooks, then Email**.
2. Event name example: `weather_alert`.
3. Email body may use `{{Value1}}` (temperature), `{{Value2}}` (humidity), `{{Value3}}` (reason).
4. Put the event name and Webhooks key in `secrets.h`.
5. Firmware only sends after a successful cloud upload, and at most once per `ALERT_COOLDOWN_MS` (default 5 minutes).

## 7. Verify field updates

After the ESP32 (or Wokwi, with a real write key) is running:

1. Watch the serial monitor for `[CLOUD] ThingSpeak entry id=...`.
2. Refresh the channel. Field 1 and Field 2 last values must match the serial line `[SENSOR] Temperature=... Humidity=...`.
3. Graphs should grow a new point about every 20 seconds.

If the HTTP body is `0`, ThingSpeak rejected the update (bad key or rate limit). The firmware logs that and does not retry as a success.
