/*
 * Wokwi-ready IoT Weather Station (single file).
 *
 * 1. Open https://wokwi.com/projects/new/esp32
 * 2. Replace sketch.ino with this file.
 * 3. Replace diagram.json with the file in this folder.
 * 4. Add libraries: "DHT sensor library" and "Adafruit Unified Sensor".
 * 5. Press the green play button. Open the Serial Monitor.
 *
 * Optional: put a real ThingSpeak write key below to publish from the simulator.
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <DHT.h>
#include <string.h>

#define WOKWI_SIMULATION 1
#define WIFI_SSID "Wokwi-GUEST"
#define WIFI_PASSWORD ""
#define WIFI_CHANNEL 6

#define THINGSPEAK_WRITE_API_KEY "YOUR_THINGSPEAK_WRITE_API_KEY"
#define IFTTT_EVENT_NAME "YOUR_IFTTT_EVENT_NAME"
#define IFTTT_WEBHOOK_KEY "YOUR_IFTTT_WEBHOOK_KEY"

#define DHT_PIN 4
#define DHT_TYPE DHT22
#define STATUS_LED_PIN 2

#define SENSOR_RETRY_COUNT 3
#define SENSOR_RETRY_DELAY_MS 2000
#define MIN_VALID_TEMP_C -40.0f
#define MAX_VALID_TEMP_C 80.0f
#define MIN_VALID_HUM_PCT 0.0f
#define MAX_VALID_HUM_PCT 100.0f

#define UPLOAD_INTERVAL_MS 20000UL
#define WIFI_CONNECT_TIMEOUT_MS 20000UL
#define WIFI_RETRY_DELAY_MS 5000UL
#define HTTP_TIMEOUT_MS 12000
#define UPLOAD_RETRY_COUNT 2

#define USE_HTTPS 0
#define THINGSPEAK_HOST "api.thingspeak.com"

#define ENABLE_IFTTT_ALERTS 1
#define TEMP_HIGH_C 35.0f
#define TEMP_LOW_C 10.0f
#define HUM_HIGH_PCT 80.0f
#define HUM_LOW_PCT 20.0f
#define ALERT_COOLDOWN_MS 300000UL
#define SERIAL_BAUD 115200

bool isPlaceholder(const char *value) {
  return value == nullptr || value[0] == '\0' || strstr(value, "YOUR_") != nullptr;
}

DHT dht(DHT_PIN, DHT_TYPE);

struct SensorReading {
  float temperatureC;
  float humidityPct;
  bool valid;
};

unsigned long lastUploadMs = 0;
unsigned long lastAlertMs = 0;
unsigned long wifiBackoffMs = WIFI_RETRY_DELAY_MS;
bool wifiEverConnected = false;

void validateConfiguration();
void connectWiFi();
void maintainWiFi();
SensorReading readSensorWithRetry();
bool inRange(float value, float minValue, float maxValue);
void logReading(const SensorReading &reading);
bool uploadToThingSpeak(const SensorReading &reading);
void checkThresholdsAndAlert(const SensorReading &reading);
bool sendIftttEmailWebhook(const SensorReading &reading, const String &reason);
void blinkIdle();

void setup() {
  pinMode(STATUS_LED_PIN, OUTPUT);
  digitalWrite(STATUS_LED_PIN, LOW);
  Serial.begin(SERIAL_BAUD);
  delay(1000);

  Serial.println();
  Serial.println(F("========================================"));
  Serial.println(F(" IoT Weather Station - Wokwi simulation"));
  Serial.println(F("========================================"));

  dht.begin();
  validateConfiguration();
  connectWiFi();
}

void loop() {
  maintainWiFi();

  const unsigned long now = millis();
  if (now - lastUploadMs < UPLOAD_INTERVAL_MS && lastUploadMs != 0) {
    blinkIdle();
    return;
  }

  SensorReading reading = readSensorWithRetry();
  if (!reading.valid) {
    Serial.println(F("[SENSOR] No valid reading this cycle; skipping cloud upload."));
    lastUploadMs = now;
    return;
  }

  logReading(reading);

  if (WiFi.status() == WL_CONNECTED) {
    const bool uploaded = uploadToThingSpeak(reading);
    if (uploaded) {
      checkThresholdsAndAlert(reading);
    }
  } else {
    Serial.println(F("[WIFI] Offline; queued cycle skipped (no local buffer)."));
  }

  lastUploadMs = millis();
}

void validateConfiguration() {
  if (isPlaceholder(THINGSPEAK_WRITE_API_KEY)) {
    Serial.println(F("[CONFIG] ThingSpeak write API key is a placeholder. Uploads will be skipped."));
  }
  if (ENABLE_IFTTT_ALERTS &&
      (isPlaceholder(IFTTT_WEBHOOK_KEY) || isPlaceholder(IFTTT_EVENT_NAME))) {
    Serial.println(F("[CONFIG] IFTTT placeholders present. Firmware email webhook disabled."));
  }
  Serial.println(F("[CONFIG] WOKWI_SIMULATION=1 (Wokwi-GUEST Wi-Fi, HTTP)."));
}

void connectWiFi() {
  Serial.printf("[WIFI] Connecting to %s ...\n", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.persistent(false);
  WiFi.setAutoReconnect(true);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD, WIFI_CHANNEL);

  const unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < WIFI_CONNECT_TIMEOUT_MS) {
    digitalWrite(STATUS_LED_PIN, !digitalRead(STATUS_LED_PIN));
    delay(400);
    Serial.print('.');
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    wifiEverConnected = true;
    wifiBackoffMs = WIFI_RETRY_DELAY_MS;
    digitalWrite(STATUS_LED_PIN, HIGH);
    Serial.printf("[WIFI] Connected. IP=%s RSSI=%d dBm\n",
                  WiFi.localIP().toString().c_str(), WiFi.RSSI());
  } else {
    digitalWrite(STATUS_LED_PIN, LOW);
    Serial.println(F("[WIFI] Connection timed out."));
    WiFi.disconnect(true, false);
  }
}

void maintainWiFi() {
  if (WiFi.status() == WL_CONNECTED) {
    if (!wifiEverConnected) {
      wifiEverConnected = true;
      Serial.printf("[WIFI] Link up. IP=%s\n", WiFi.localIP().toString().c_str());
    }
    digitalWrite(STATUS_LED_PIN, HIGH);
    return;
  }

  digitalWrite(STATUS_LED_PIN, LOW);
  static unsigned long lastAttemptMs = 0;
  const unsigned long now = millis();
  if (now - lastAttemptMs < wifiBackoffMs) {
    return;
  }
  lastAttemptMs = now;
  Serial.println(F("[WIFI] Disconnected. Retrying..."));
  connectWiFi();
  if (WiFi.status() != WL_CONNECTED) {
    wifiBackoffMs = min(wifiBackoffMs * 2UL, 60000UL);
    Serial.printf("[WIFI] Next retry in %lu ms\n", wifiBackoffMs);
  }
}

SensorReading readSensorWithRetry() {
  SensorReading reading = {NAN, NAN, false};

  for (int attempt = 1; attempt <= SENSOR_RETRY_COUNT; attempt++) {
    float humidity = dht.readHumidity();
    float temperature = dht.readTemperature();

    if (isnan(humidity) || isnan(temperature)) {
      Serial.printf("[SENSOR] DHT22 read failed (attempt %d/%d).\n",
                    attempt, SENSOR_RETRY_COUNT);
    } else if (!inRange(temperature, MIN_VALID_TEMP_C, MAX_VALID_TEMP_C) ||
               !inRange(humidity, MIN_VALID_HUM_PCT, MAX_VALID_HUM_PCT)) {
      Serial.printf("[SENSOR] Out-of-range T=%.2f H=%.2f (attempt %d/%d).\n",
                    temperature, humidity, attempt, SENSOR_RETRY_COUNT);
    } else {
      reading.temperatureC = temperature;
      reading.humidityPct = humidity;
      reading.valid = true;
      return reading;
    }

    if (attempt < SENSOR_RETRY_COUNT) {
      delay(SENSOR_RETRY_DELAY_MS);
    }
  }

  return reading;
}

bool inRange(float value, float minValue, float maxValue) {
  return value >= minValue && value <= maxValue;
}

void logReading(const SensorReading &reading) {
  Serial.printf("[SENSOR] Temperature=%.2f C  Humidity=%.2f %%RH\n",
                reading.temperatureC, reading.humidityPct);
}

bool uploadToThingSpeak(const SensorReading &reading) {
  if (isPlaceholder(THINGSPEAK_WRITE_API_KEY)) {
    Serial.println(F("[CLOUD] Placeholder API key; upload skipped."));
    return false;
  }

  String url = String(USE_HTTPS ? "https://" : "http://") + THINGSPEAK_HOST +
               "/update?api_key=" + THINGSPEAK_WRITE_API_KEY +
               "&field1=" + String(reading.temperatureC, 2) +
               "&field2=" + String(reading.humidityPct, 2);

  for (int attempt = 1; attempt <= UPLOAD_RETRY_COUNT; attempt++) {
    HTTPClient http;
    http.setTimeout(HTTP_TIMEOUT_MS);

    if (!http.begin(url)) {
      Serial.printf("[CLOUD] HTTP begin failed (attempt %d/%d).\n",
                    attempt, UPLOAD_RETRY_COUNT);
      http.end();
      delay(500);
      continue;
    }

    const int status = http.GET();
    const String body = http.getString();
    http.end();

    if (status == 200) {
      const long entryId = body.toInt();
      if (entryId > 0) {
        Serial.printf("[CLOUD] ThingSpeak entry id=%ld\n", entryId);
        return true;
      }
      Serial.printf("[CLOUD] ThingSpeak rejected update (body='%s'). Rate limit or bad key.\n",
                    body.c_str());
      return false;
    }

    Serial.printf("[CLOUD] Upload failed HTTP %d body='%s' (attempt %d/%d).\n",
                  status, body.c_str(), attempt, UPLOAD_RETRY_COUNT);
    delay(750);
  }

  return false;
}

void checkThresholdsAndAlert(const SensorReading &reading) {
  const bool hot = reading.temperatureC > TEMP_HIGH_C;
  const bool cold = reading.temperatureC < TEMP_LOW_C;
  const bool humid = reading.humidityPct > HUM_HIGH_PCT;
  const bool dry = reading.humidityPct < HUM_LOW_PCT;

  if (!(hot || cold || humid || dry)) {
    return;
  }

  String reason;
  if (hot) reason += "temperature above ";
  if (cold) reason += "temperature below ";
  if (humid) reason += "humidity above ";
  if (dry) reason += "humidity below ";
  reason += "configured limit";

  Serial.printf("[ALERT] Threshold crossed: T=%.2f C (%.1f..%.1f) H=%.2f %% (%.1f..%.1f)\n",
                reading.temperatureC, TEMP_LOW_C, TEMP_HIGH_C,
                reading.humidityPct, HUM_LOW_PCT, HUM_HIGH_PCT);

  const unsigned long now = millis();
  if (now - lastAlertMs < ALERT_COOLDOWN_MS && lastAlertMs != 0) {
    Serial.println(F("[ALERT] Cooldown active; not sending another email webhook."));
    return;
  }

  if (sendIftttEmailWebhook(reading, reason)) {
    lastAlertMs = now;
  }
}

bool sendIftttEmailWebhook(const SensorReading &reading, const String &reason) {
  if (!ENABLE_IFTTT_ALERTS || isPlaceholder(IFTTT_WEBHOOK_KEY) ||
      isPlaceholder(IFTTT_EVENT_NAME)) {
    Serial.println(F("[ALERT] Use ThingSpeak MATLAB/React email (see cloud/thingspeak). IFTTT not configured."));
    return false;
  }

  String url = "http://maker.ifttt.com/trigger/" + String(IFTTT_EVENT_NAME) +
               "/with/key/" + String(IFTTT_WEBHOOK_KEY) +
               "?value1=" + String(reading.temperatureC, 2) +
               "&value2=" + String(reading.humidityPct, 2) +
               "&value3=" + reason;

  HTTPClient http;
  http.setTimeout(HTTP_TIMEOUT_MS);
  if (!http.begin(url)) {
    Serial.println(F("[ALERT] IFTTT HTTP begin failed."));
    return false;
  }

  const int status = http.GET();
  const String body = http.getString();
  http.end();

  if (status >= 200 && status < 300) {
    Serial.printf("[ALERT] IFTTT webhook accepted HTTP %d\n", status);
    return true;
  }

  Serial.printf("[ALERT] IFTTT webhook failed HTTP %d body='%s'\n", status, body.c_str());
  return false;
}

void blinkIdle() {
  static unsigned long lastBlink = 0;
  if (millis() - lastBlink > 1000) {
    lastBlink = millis();
    if (WiFi.status() == WL_CONNECTED) {
      digitalWrite(STATUS_LED_PIN, !digitalRead(STATUS_LED_PIN));
    }
  }
  delay(50);
}
