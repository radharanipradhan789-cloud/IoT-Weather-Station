## Verified Test Results

The following tests were completed using the Wokwi ESP32 simulation and the configured ThingSpeak channel.

| Test                   | Test Performed                                          | Observed Result                                             | Status |
| ---------------------- | ------------------------------------------------------- | ----------------------------------------------------------- | ------ |
| Wi-Fi connectivity     | Started the Wokwi simulation                            | ESP32 connected to Wokwi-GUEST and received an IP address   | Pass   |
| Temperature reading    | Read the DHT22 sensor                                   | Temperature was displayed in the Serial Monitor             | Pass   |
| Humidity reading       | Read the DHT22 sensor                                   | Relative humidity was displayed in the Serial Monitor       | Pass   |
| High-temperature alert | Set simulated temperature above 35°C                    | High-temperature alert was displayed                        | Pass   |
| High-humidity alert    | Set simulated humidity above 80%                        | High-humidity alert was displayed                           | Pass   |
| ThingSpeak upload      | Uploaded sensor data using the configured Write API Key | Serial Monitor displayed `[CLOUD] Upload successful.`       | Pass   |
| Cloud visualization    | Opened the ThingSpeak Private View dashboard            | Temperature and humidity graphs displayed recorded readings | Pass   |

### Tests Not Yet Verified

The following features have not been confirmed and must not be marked as passed without testing:

* Email alert delivery through ThingSpeak React and MATLAB Analysis.
* IFTTT email notifications.
* Physical ESP32 and DHT22 hardware operation.
* Wi-Fi disconnection recovery.
* Sensor failure and out-of-range handling.
* PlatformIO compilation and automated repository validation.

Keep the corresponding tests in this document as future verification steps. Record their actual results after performing them.
