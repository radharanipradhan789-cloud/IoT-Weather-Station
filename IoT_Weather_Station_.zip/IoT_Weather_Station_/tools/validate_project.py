#!/usr/bin/env python3
"""Structural checks for the IoT weather station repository.

Does not flash hardware, call ThingSpeak, or send email.
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

REQUIRED_FILES = [
    "README.md",
    "TECHNICAL_REPORT.md",
    "TEST_CASES.md",
    "DEPENDENCIES.md",
    "platformio.ini",
    "firmware/arduino/IoT_Weather_Station/IoT_Weather_Station.ino",
    "firmware/arduino/IoT_Weather_Station/config.h",
    "firmware/arduino/IoT_Weather_Station/secrets.h",
    "firmware/arduino/IoT_Weather_Station/secrets.h.example",
    "simulation/wokwi/diagram.json",
    "simulation/wokwi/sketch.ino",
    "simulation/wokwi/libraries.txt",
    "simulation/wokwi/wokwi.toml",
    "cloud/thingspeak/CHANNEL_SETUP.md",
    "cloud/thingspeak/matlab_threshold_email.m",
    "docs/wiring.md",
    "docs/architecture.md",
]

PLACEHOLDER_FILES = [
    "firmware/arduino/IoT_Weather_Station/secrets.h",
    "firmware/arduino/IoT_Weather_Station/secrets.h.example",
    "simulation/wokwi/secrets.h",
    "cloud/thingspeak/matlab_threshold_email.m",
]


def fail(message: str) -> None:
    print(f"FAIL: {message}")


def main() -> int:
    errors = 0
    print(f"Repository: {ROOT}")

    for relative in REQUIRED_FILES:
        path = ROOT / relative
        if not path.is_file():
            fail(f"missing {relative}")
            errors += 1
        else:
            print(f"OK   {relative}")

    sketch = (ROOT / "firmware/arduino/IoT_Weather_Station/IoT_Weather_Station.ino").read_text(
        encoding="utf-8"
    )
    config = (ROOT / "firmware/arduino/IoT_Weather_Station/config.h").read_text(encoding="utf-8")
    firmware_text = sketch + "\n" + config
    for token in (
        "DHT",
        "WiFi.begin",
        "api.thingspeak.com",
        "field1",
        "field2",
        "readSensorWithRetry",
        "uploadToThingSpeak",
        "checkThresholdsAndAlert",
    ):
        if token not in firmware_text:
            fail(f"firmware missing token {token!r}")
            errors += 1
        else:
            print(f"OK   firmware contains {token}")

    diagram = (ROOT / "simulation/wokwi/diagram.json").read_text(encoding="utf-8")
    for token in ("board-esp32-devkit-c-v4", "wokwi-dht22", "esp:4"):
        if token not in diagram:
            fail(f"Wokwi diagram missing {token!r}")
            errors += 1
        else:
            print(f"OK   diagram contains {token}")

    for relative in PLACEHOLDER_FILES:
        text = (ROOT / relative).read_text(encoding="utf-8")
        if "YOUR_" not in text:
            fail(f"{relative} should still contain YOUR_ placeholders")
            errors += 1
        else:
            print(f"OK   placeholders present in {relative}")

    banned = ("sk_live", "AKIA")
    for relative in PLACEHOLDER_FILES:
        text = (ROOT / relative).read_text(encoding="utf-8")
        for token in banned:
            if token in text:
                fail(f"{relative} looks like it contains a real secret pattern {token}")
                errors += 1

    if errors:
        print(f"\n{errors} check(s) failed.")
        return 1
    print("\nAll structural checks passed. Hardware/cloud tests were not run.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
