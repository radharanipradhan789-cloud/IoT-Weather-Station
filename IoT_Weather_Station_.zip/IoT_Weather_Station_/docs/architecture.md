# System Architecture

```mermaid
flowchart LR
    DHT22["DHT22 Sensor<br/>Temperature + Humidity"] -->|GPIO 4| ESP32["ESP32<br/>Firmware"]
    ESP32 -->|Wi-Fi| AP["Wokwi Wi-Fi Network"]
    AP -->|HTTP GET /update| TS["ThingSpeak<br/>Field 1: Temperature<br/>Field 2: Humidity"]
    TS --> Charts["Temperature and Humidity Graphs"]
    ESP32 --> Alerts["Threshold Alerts<br/>Serial Monitor"]
    TS -.-> Optional["Optional Email Alerts<br/>React + MATLAB Analysis"]
```

## System Operation

1. The DHT22 sensor provides temperature and humidity readings to the ESP32 through GPIO 4.
2. The ESP32 connects to the Wokwi Wi-Fi network in station mode.
3. The firmware reads sensor values and checks them against configured thresholds.
4. When a threshold is exceeded, the firmware prints an alert in the Serial Monitor.
5. The ESP32 uploads temperature and humidity data to ThingSpeak using HTTP requests.
6. ThingSpeak stores the submitted measurements and displays them as time-series graphs.
7. Email notifications through ThingSpeak React and MATLAB Analysis are an optional feature that has not yet been verified.
8. Physical hardware operation and optional IFTTT email notifications have not been verified.

```

### Step 2: Save the file

Press **`Ctrl + S`**.

**Important:** This version documents the functionality you have actually demonstrated without claiming that untested features work. Once saved, we can continue preparing your technical report for submission.
```
